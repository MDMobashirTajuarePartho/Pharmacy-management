

/**
 *
 * @author Sani
 */
class color {
    
}
