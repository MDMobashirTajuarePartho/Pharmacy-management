public class Start {
    public static void main(String[] args) {
         //new   Dashboard() ;
       // new Registration();
         new Login();
	 //new AddMedicine();
    // new MedicineReport();
   //  new AboutProject();
 //  new AddSalesReport();
 
    }
}